import bathroom from './bathroom.png'
import bed from './bed.png'
import camp from './camp.png'
import cave from './cave.png'
import festival from './festival.png'
import five from './Five.png'
import hotelpool from './hotelpool.png'
import temple from './temple.png'
import ledis from './ledis.png'
import nature from './nature.png'
import office from './office.png'
import old from './old.png'
import resort from './resort.png'
import sea from './sea.png'
import smile from './smile.png'
import sunrise from './sunrise.png'
import msunrise from './msunrise.png'
import sydney from './sydney.png'
import tower from './tower.png'
import waterfall from './waterfall.png'
import Yifei from './Yifei.png'
import Anthony from './Anthony.png'
import yang3 from './yang-deng3.png'
import kaori from './kaori.png'
import yirandingAi from './yirandingAi.png'
import WorldMap from './WorldMap.png'
import hero from './hero.png'
import shangai from './shangai.png'
import maldivs from './maldivs.png'
import mongolia from './mongolia.png'
import morocco from './morocco.png'
import map from './Map.png'
import Pricehistory from './Pricehistory.png'
import holes from './holes.png'
import wall from './wall.png'
import seoul from './seoul.png'
import kenya from './kenya.png'
import bag from './bag.png'
import plane from  './Plane.png'
import plane1 from  './Plane1.png'
import plane2 from  './Plane2.png'
import plane3 from  './Plane3.png'
import planebody from  './planebody.png'
import whitespace from './whitespace.png'
import business from './BusinessSeats.png'
import economy from './EconomySeats.png'
import map1 from './Map1.png'
import Ryoka from './Ryoka.png'
import Bessho from './Bessho.png'
import HotelFlag from './HotelFlag.png'
import fiveHole from './fiveHole.png'
import kimono from './kimono.png'
import teamLab from './teamLab.png'

export {
    whitespace,
    kimono,
    teamLab,
    Bessho,
    HotelFlag,
    fiveHole,
    Ryoka,
    business,
    economy,
    Pricehistory,
    planebody,
    plane,
    plane1,
    plane2,
    plane3,
    bag,
    seoul,
    kenya,
    holes,
    wall,
    hero,
    map,
    map1,
    morocco,
    maldivs,
    mongolia,
    tower,
    Yifei,
    waterfall,
    Anthony,
    kaori,
    yang3,
    shangai,
    yirandingAi,
    bathroom,
    msunrise,
    bed,
    camp,
    cave,
    festival,
    five,
    hotelpool,
    temple,
    ledis,
    nature,
    office,
    old,
    resort,
    sea,
    smile,
    sunrise,
    sydney,
    WorldMap
}